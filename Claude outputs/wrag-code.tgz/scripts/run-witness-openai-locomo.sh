#!/usr/bin/env bash
# LoCoMo (10 conversas) com WitnessRAG usando a API pública da OpenAI.
# Mesmo perfil registrado de scripts/run-witness-azure-locomo.sh; só o LLM muda.
#
#   OPENAI_API_KEY no .env (ou no ambiente), depois:
#   bash scripts/run-witness-openai-locomo.sh [saida]
#
# Variáveis úteis: MODEL (gpt-4o-mini), LOCOMO_CONVERSATION (all | 0 | 0,3,7),
# METHOD (witnessrag | hybrid), CONCURRENCY (8), EMBED_DEVICE (cpu | cuda),
# QUESTIONS (vazio = todas; use p.ex. 5 para um smoke test).
set -euo pipefail
cd "$(dirname "$0")/.."

if [[ -f .env ]]; then
  set -a
  # shellcheck disable=SC1091
  source .env
  set +a
fi
: "${OPENAI_API_KEY:?Defina OPENAI_API_KEY no .env ou no ambiente}"

if [[ -z "${BENCH_PYTHON:-}" ]]; then
  for candidate in .venv-bench/bin/python .venv-bench/Scripts/python.exe .venv/bin/python .venv/Scripts/python.exe; do
    [[ -x "$candidate" ]] && { BENCH_PYTHON="$PWD/$candidate"; break; }
  done
  BENCH_PYTHON=${BENCH_PYTHON:-python}
fi

MODEL=${MODEL:-gpt-4o-mini}
METHOD=${METHOD:-witnessrag}
OUTPUT=${1:-runs/witness-suite-locomo-openai-${MODEL}-${METHOD}}
CONVERSATION=${LOCOMO_CONVERSATION:-all}
TOKENIZER_MODEL=${WRAG_TOKENIZER_MODEL:-Qwen/Qwen2.5-14B-Instruct}
TOP_K=${TOP_K:-5}
CHUNK_TOKENS=${CHUNK_TOKENS:-2048}
CACHE_DIR=${CACHE_DIR:-"$PWD/runs/.cache/witness-openai"}
mkdir -p "$OUTPUT" "$CACHE_DIR"

export WRAG_LLM_BACKEND=openai OPENAI_MODEL="$MODEL"
export WRAG_CONTINUE_ON_CONTENT_FILTER=1
export WRAG_EMBED_BACKEND=st
export WRAG_EMBED_MODEL=${EMBED_MODEL:-BAAI/bge-m3}
export WRAG_EMBED_DEVICE=${EMBED_DEVICE:-cpu}
export WRAG_CACHE_DIR="$CACHE_DIR"
export WRAG_LLM_CACHE=1 WRAG_EMBED_CACHE=1 PYTHONHASHSEED=42
export WRAG_AZURE_CONCURRENCY=${CONCURRENCY:-8}

"$BENCH_PYTHON" -m wrag.cli diag-openai --model "$MODEL"

RESUME=()
[[ -f "$OUTPUT/pilot.json" ]] && RESUME+=(--resume)
QUESTION_FLAGS=()
[[ -n "${QUESTIONS:-}" ]] && QUESTION_FLAGS+=(--questions "$QUESTIONS")
case "$METHOD" in
  witnessrag)
    METHOD_FLAGS=(--binding-aware-grounding --vocab-compile --hybrid-fallback
      --dialogue-ie --selective-witness --gap-context-rescue)
    ;;
  hybrid) METHOD_FLAGS=() ;;
  *) echo "METHOD deve ser witnessrag ou hybrid." >&2; exit 2 ;;
esac

"$BENCH_PYTHON" -m wrag.pilot --backend openai --model "$MODEL" \
  --concurrency "$WRAG_AZURE_CONCURRENCY" --gpu "${GPU:-0}" \
  --tokenizer-model "$TOKENIZER_MODEL" \
  --dataset locomo --locomo-conversation "$CONVERSATION" --methods "$METHOD" \
  "${QUESTION_FLAGS[@]}" \
  --embed-model "$WRAG_EMBED_MODEL" --embed-device "$WRAG_EMBED_DEVICE" \
  --locomo-chunk-tokens "$CHUNK_TOKENS" --locomo-ie-window-tokens 512 --top-k "$TOP_K" --qa-max-tokens 128 \
  --witness-candidate-pool 20 --answer-set --temporal-annotations --evidence-reader \
  "${METHOD_FLAGS[@]}" \
  --cache-dir "$CACHE_DIR" \
  --hours "${HOURS:-72}" --output "$OUTPUT" "${RESUME[@]}"
